import {
    Button,
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    FlatList,
    ProgressBarAndroid,
    Pressable
  } from 'react-native';
  import React, {useEffect, useState} from 'react';
import CircularProgress from './CircularProgress';

const ScoreCard = ({navigation,route}) => {
  const {data}=route?.params;
    useEffect(()=>{
     console.log(route?.params?.data)
     ;
    },[])
    return(
        <View style={{flex:1,alignItems:"center",paddingTop:15,backgroundColor:"#f8f8fb"}}>
          <View
                         style={{
                          backgroundColor:"#fff",
                          width:"90%",
                          borderColor: "#86889433",
                          borderWidth:1,
                          justifyContent:"space-between",
                          padding:15,
                          borderRadius:10,
                          shadowColor: "gray",
                          shadowOffset: {width: 0, height: 0},
                          shadowOpacity: 10,
                          shadowRadius: 0,
                          elevation: 0,
                        margin:0,
                        
                        }}>
                          <View style={{flexDirection:"row",marginBottom:8}}>
                          <View style={{width:50,height:50,borderRadius:25,backgroundColor:data.section=="science"?"#FA661B":"#FBB03B",justifyContent:"center",alignItems:"center"}}>
                            <Text style={{fontSize:18,color:"#fff"}}>{data.firstName?.split("")[0]}</Text>
                          </View>
                          <View style={{paddingVertical:5,justifyContent:"space-evenly",marginLeft:10}}>
                         <Text style={{fontSize:15,color:"#000",fontWeight:"500"}}>{data.firstName+" "+data.lastName}</Text>
                       <Text style={styles.text}>{data.section}</Text>
                    </View> 
                        </View>  

                    <Text style={styles.boldText}>{"Score:"+" "+data.scoreInPercentage+"%"}</Text>    
                    

            
                    <ProgressBarAndroid 
                        progress={data?.scoreInPercentage/100}
                        styleAttr="Horizontal" 
                        indeterminate={false}
                        color="#2196F3"
                         />
                  
                    <View style={{flexDirection:"row",justifyContent:"space-between"}}>
                    <Text style={styles.boldText}>Result</Text>
                    <Text style={styles.text}>{data.scoreInPercentage<40?"Fail":"Pass"}</Text>
                    </View>
                        </View> 
                      
        </View>
    )
    
}

export default ScoreCard; 

const styles = StyleSheet.create({
    text:{fontSize:14,color:"#717171",},
    boldText:{fontSize:14,color:"#000",fontWeight:"500"}
})

