import * as ICONS from './Icons';
import * as STRINGS from './Strings';
import {COLORS, FONTS, SIZES} from './Theme';
export {STRINGS, ICONS, COLORS, FONTS, SIZES};
