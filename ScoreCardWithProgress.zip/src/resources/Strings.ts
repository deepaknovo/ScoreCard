// Intro Module
const APP_NAME = 'APP';
const SIGNUP_TEXT = 'Create Your Account';
const LOGIN_TEXT = 'Continue Your Journey';
const HAVE_ACCOUNT_TEXT = 'Already have an account';
export {APP_NAME, LOGIN_TEXT, SIGNUP_TEXT, HAVE_ACCOUNT_TEXT};
