const CHAT_ICON = require('../assets/chat.png');

export {CHAT_ICON};
